﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace DeAn.Controllers
{
    public class TruyenngontinhController : Controller
    {
        // GET: Truyenngontinh
        public ActionResult ELN()
        {
            return View();
        }
        public ActionResult VTK()
        {
            return View();
        }
        public ActionResult KDD()
        {
            return View();
        }
        public ActionResult Chuong234()
        {
            return View();
        }
    }
}