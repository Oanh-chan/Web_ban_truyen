﻿using System;
using DeAn.Models;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Net;

namespace B3TH.Controllers
{
    public class HomeController : Controller
    {
        private DBSportStoreEntities db = new DBSportStoreEntities();
        public ActionResult Index()
        {
            return View();
        }
        public ActionResult Index3()
        {
            return View();
        }
        public ActionResult View1()
        {
            var products = db.Products;
            return View(products.ToList());
        }
        public ActionResult TrangChu0()
        {
            var products = db.Products;
            return View(products.ToList());
        }
        public ActionResult GioHang()
        {
            var products = db.Products;
            return View(products.ToList());
        }
        public ActionResult About()
        {
            ViewBag.Message = "Your application description page.";

            return View();
        }

        public ActionResult Contact()
        {
            ViewBag.Message = "Your contact page.";

            return View();
        }
        public ActionResult Danhmuc()
        {
            var products = db.Products;
            return View(products.ToList());
        }

        public ActionResult Theloai()
        {
            return View();
        }
        public ActionResult Test()
        {
            return View();
        }
        public ActionResult Trangchu()
        {
            return View();
        }
        public ActionResult Trangchu2()
        {
            var products = db.Products;
            return View(products.ToList());
        }
        public ActionResult Đangnhap()
        {
            return View();
        }
        public ActionResult Đangky()
        {
            return View();
        }
        public ActionResult Nhomdich()
        {
            return View();
        }
        public ActionResult Lienhe()
        {
            return View();
        }
        public ActionResult Truyen_A_No()
        {
            return View();
        }
        public ActionResult Nhap()
        {
            return View();
        }
    }
}