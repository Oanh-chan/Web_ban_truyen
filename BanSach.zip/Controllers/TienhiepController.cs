﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace DeAn.Controllers
{
    public class TienhiepController : Controller
    {
        // GET: Tienhiep
        public ActionResult Index()
        {
         
            return View();
        }
        public ActionResult Tuongtutan ()
        {
            return View();
        }
        public ActionResult Tuongtutan1()
        {
            return View();
        }
    }
}