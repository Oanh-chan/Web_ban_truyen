﻿using DeAn.Models;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Data;
using System.IO;
using System.Text;
using System.Threading;

namespace DeAn.Controllers
{
    public class LoginController : Controller
    {
       DBSportStoreEntities database = new DBSportStoreEntities();
        // GET: Login
        public ActionResult Index1()
        {
            return View(database.Customers.ToList());
        }
        public ActionResult Index2()
        {
            return View();
        }
        [HttpGet]
        public ActionResult FormLogin()
        {
            return View();
        }
        [HttpPost]
        public ActionResult Authen(Customer _user)
        {
            var check = database.Customers.Where(s => s. EmailCus.Equals(_user.EmailCus)&&s.PassCus.Equals(_user.PassCus)).FirstOrDefault();
            if (check == null)
            {
               _user.LoginErrorMessage="Email hoặc mật khẩu không đúng! Vui lòng thử lại!";

                return View("FormLogin", _user);
            }
            else
            {
                
                Session["IDCus"] = _user.IDCus;
                Session["EmailCus"] = _user.EmailCus;
                return RedirectToAction("Index3", "Home");
            }
        }
        [HttpGet]
        public ActionResult Register()
        {
            return View();
        }
        [HttpPost]
        public ActionResult Register(Customer cust)
        {
            if (ModelState.IsValid)
            {
               
                // Kiểm tra xem có người nào đăng ký với tên đăng nhập này hay chưa
                var khachhang = database.Customers.FirstOrDefault(k => k.EmailCus == cust.EmailCus);
                if (khachhang == null)
                { 
                    database.Configuration.ValidateOnSaveEnabled = false;
                    database.Customers.Add(cust);
                    database.SaveChanges();
                    return RedirectToAction("Index2");
                }
                
                else
                {
                    ViewBag.error = "Email đã tồn tại";
                    return View();
                }
            }
            return View();
        }
        public ActionResult Logout()
        {
            Session.Abandon();
            return RedirectToAction("FormLogin", "Login");
        }
    }

    }


  