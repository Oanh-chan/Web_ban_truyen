﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace DeAn.Controllers
{
    public class khachhangController : Controller
    {
        // GET: khachhang
        public ActionResult Index()
        {
            return View();
        }
    }
}