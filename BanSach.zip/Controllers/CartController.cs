﻿using DeAn.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.UI.WebControls;

namespace DeAn.Controllers
{
    public class CartController : Controller
    {
        DBSportStoreEntities _db = new DBSportStoreEntities();
        public Cart1 GetCart()
        {
            Cart1 cart = Session["Cart"] as Cart1;
            if(cart == null || Session["Cart"] == null)
            {
                cart = new Cart1();
                Session["Cart"] = cart;
            }
            return cart;
        }
        // GET: Cart
       public ActionResult AddtoCart(int id)
        {
            var pro = _db.Products.SingleOrDefault(s => s.ProductID == id);
            if(pro != null)
            {
                GetCart().Add(pro);

            }
            return RedirectToAction("ShowToCart", "Cart");
        }
        public ActionResult ShowToCart()
        {
            if (Session["Cart"] == null)
                return RedirectToAction("ShowToCart", "Cart");
            Cart1 cart = Session["Cart"] as Cart1;
            return View(cart);
        }
        public ActionResult Update_Quantity_Cart(FormCollection form)
        {
            Cart1 cart = Session["Cart"] as Cart1;
            int id_pro = int.Parse(form["ID_Product"]);
            int quantity = int.Parse(form["Quantity"]);
            cart.Update_Quantity_Shopping(id_pro, quantity);
            return RedirectToAction("ShowToCart", "Cart");
        }
       public ActionResult RemoveCart(int id)
        {
            Cart1 cart = Session["Cart"] as Cart1;
            cart.Remove_CartItem(id);
            return RedirectToAction("ShowToCart", "Cart");
        }
        public PartialViewResult BagCart()
        {
            int _t_item = 0;
            Cart1 cart = Session["Cart"] as Cart1;
            if(cart != null)
            {
                _t_item = cart.Total_Quantity();
            }
            ViewBag.infoCart = _t_item;
            return PartialView("BagCart");
        }
    }
}