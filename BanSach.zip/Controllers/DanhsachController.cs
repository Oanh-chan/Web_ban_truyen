﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace DeAn.Controllers
{
    public class DanhsachController : Controller
    {
        // GET: Danhsach
        public ActionResult Index()
        {
            return View();
        }
        public ActionResult danhsach()
        {
            return View();
        }
        public ActionResult truyenhot()
        {
            return View();
        }
        public ActionResult truyenfull()
        {
            return View();
        }
        public ActionResult tienhiephay()
        {
            return View();
        }
        public ActionResult kiemhiephay()
        {
            return View();
        }
        public ActionResult truyenteenhay()
        {
            return View();
        }
        public ActionResult ngontinhhay()
        {
            return View();
        }
        public ActionResult ngontinhsac()
        {
            return View();
        }
        public ActionResult ngontinhnguoc()
        {
            return View();
        }
        public ActionResult ngontinhsung()
        {
            return View();
        }
        public ActionResult ngontinhhai()
        {
            return View();
        }
        public ActionResult dammyhai()
        {
            return View();
        }
        public ActionResult dammyhay()
        {
            return View();
        }
        public ActionResult dammyhvan()
        {
            return View();
        }
        public ActionResult dammysac()
        {
            return View();
        }
    }
}