﻿using System;
using DeAn.Models;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace DeAn.Controllers
{
    public class TheloaiController : Controller
    {
       
        [HttpGet]
        public ActionResult Create()
        {
            return View();
        }
        [HttpPost]
       
        
        public ActionResult Tienhiep()
        {
            return View();
        }
        public ActionResult Ngontinh()
        {
            return View();
        }
        public ActionResult Lichsu()
        {
            return View();
        }
        public ActionResult TruyenHaihuoc()
        {
            return View();
        }
        public ActionResult TruyenTeen()
        {
            return View();
        }
        public ActionResult Đothi()
        {
            return View();
        }
        public ActionResult Xuyennhanh()
        {
            return View();
        }
        public ActionResult Huyenhuyen()
        {
            return View();
        }
        public ActionResult Digioi()
        {
            return View();
        }
        public ActionResult Dammy()
        {
            return View();
        }
        public ActionResult Truyensac()
        {
            return View();
        }
        public ActionResult Tieuthuyet()
        {
            return View();
        }
        public ActionResult Truyenngan()
        {
            return View();
        }
        public ActionResult Kiemhiep()
        {
            return View();
        }
        public ActionResult Quansu()
        {
            return View();
        }
        public ActionResult Trongsinh()
        {
            return View();
        }
        public ActionResult Xuyenkhong()
        {
            return View();
        }
        public ActionResult Ngontinhsac()
        {
            return View();
        }
        public ActionResult Vongdu()
        {
            return View();
        }
        public ActionResult Trinhtham()
        {
            return View();
        }
    }
}