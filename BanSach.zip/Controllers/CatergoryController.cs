﻿using DeAn.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace DeAn.Controllers
{
    public class CatergoryController : Controller
    {
        DBSportStoreEntities db = new DBSportStoreEntities();

        // GET: Catergory
        public ActionResult Index()
        {
            return View();
        }
        public ActionResult Catergory1(Category pro, Product n)
        {
            if (pro.IDCate == n.Category)
            {
                return RedirectToAction("Details","");
            }
            return View();
        }
    }
}